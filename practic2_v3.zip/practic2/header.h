#pragma once

#include<iostream>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <cstdio>
#include <cstring>
#include<windows.h>
#include<io.h>
#include<locale.h>
#include <stdlib.h>
#include <string.h>
#include <cstdlib>
#include <process.h>
#include <cmath>


double calculate(long  double a, long double b, long double c);
int isDouble(const char* str);