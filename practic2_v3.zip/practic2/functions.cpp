//#include "pch.h"
#include "header.h"



const long double a8 = 6378137;///  ��� wgs84
const long double pCompression8 = 1.0 / 298.257223563;///<��������� ���� double -- �������� ������ (GRS-80)
const long double b8 = a8 * (1.0 - pCompression8);
const long double sa8 = a8 * a8;
const long double sb8 = b8 * b8;
const long double seccentricity8 = (sa8 - sb8) / sa8;
const long double seccentricity28 = (sa8 - sb8) / sb8;







      long     double M (double B) {        
            double sinB = sin(B);
            double foo =  1 - seccentricity8 * sinB*sinB;
            double rc  = a8 * (1 - seccentricity8)   / sqrt (foo * foo * foo);
     //      if(Ellipsoid.l != null)
     //       Ellipsoid.l.WriteLine( IMPORTANCELEVEL.Debug
     //                     ,"B/M: {0:0.000000}/{1}", B, rc);
            return rc;
         }

         /// \brief ������ �������� ������� ���������
         ///      [���������, ������������� ������ ����, ������ ������, ���.47](http://www.geogr.msu.ru/cafedra/karta/docs/GOK/gok_lecture_3.pdf)
       long    double N (double B) {
            double sinB = sin(B);
            double foo =  1- seccentricity8 * sinB*sinB;
            double rc =   a8 / ( sqrt (foo)); 
/*
            if(Ellipsoid.l != null)
               Ellipsoid.l.WriteLine( IMPORTANCELEVEL.Debug
                          ,"B/N: {0:0.000000}/{1}", B, rc);
*/
            return rc;
         }





long  double   R   (double B) {return sqrt(N(B)* M(B));}



double calculate(long  double a, long double b, long double c, )
{
        a /=  R(10.);
        b /=  R(10.);
        c /=  R(10.);

	long double p = (a + b + c) / 2;
	long double tan_p = tan(p / 2);
	long double tan_a = tan((p - a) / 2);
	long double tan_b = tan((p - b) / 2);
	long double tan_c = tan((p - c) / 2);

	long double calc = sqrt(tan_p * tan_a * tan_b * tan_c);


	long double e = 4 * atan(calc);

	long double s = R(10) * R(10) * e;     ///

	printf("p = %lf\ntan p = %lf\ntan a = %lf\ntan b = %lf\ntan c = %lf\n", p, tan_p, tan_a, tan_b, tan_c);
	printf("square root of multiplication  = %lf\ne = %lf \nArea of triangle = %lf\n", calc, e, s);


	return s;
}
int isDouble(const char* str)
{
	if (str[0] == '-' || str[0] == '+') //check plus/minus
	{
		printf("\nToo many \"+\\-\"symbols");
		return 1;
	}
	int symbol_point = 0;
	int tab = 0;
	for (size_t i = 0; strlen(str) > i; i++)
	{
		if (isalpha(str[i]))
		{
			printf("\nContains non-number symbol(symbols) somewhere!");
			return 1;
		}

		if (str[i] == '.')
		{
			symbol_point++;
		}
		if (str[i] == '\t')
		{
			tab++;
		}

	}
	if (symbol_point > 1)
	{
		printf("\nToo many \" . \"symbols");
		return 1;
	}
	if (tab >= 1)
	{
		printf("\nHave tab symbols");
		return 1;
	}

	return 0;
}