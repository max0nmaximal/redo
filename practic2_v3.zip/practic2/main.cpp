﻿//#include "pch.h"
#include "header.h"
#pragma warning (disable: 4996)

struct point
{
	long double x, y;
	struct point *next;

};

int main(int argc, char* argv[])
{
	char* a = NULL;
	char* b = NULL;
	char* c = NULL;

	for (int i = 1; i < argc; i++)
	{
		const char* argument = argv[i];
		if (strcmp(argument, "-h") == 0)
		{
			printf("help:\n");
			printf("-h instuctions\n");
			printf("This console application calculate the area of spheric triangle\n");
			printf("Manualy enter sides of triangle by yourself:\n");
			printf("-a to enter the first spherical triangle side\n");
			printf("-b to enter the second spherical triangle side\n");
			printf("-c to enter the third spherical triangle side\n");

			exit(EXIT_SUCCESS);
		}



		else if (strcmp(argument, "-a") == 0)
		{
			if (i + 1 < argc)
			{
				a = argv[i + 1];
				i++;
			}
		}
		else if (strcmp(argument, "-b") == 0)
		{
			if (i + 1 < argc)
			{
				b = argv[i + 1];
				i++;
			}
		}
		else if (strcmp(argument, "-c") == 0)
		{
			if (i + 1 < argc)
			{
				c = argv[i + 1];
				i++;
			}
		}




	}
	bool incorrect_number = false;
	if (!a || !b || !c )
	{
		printf("Did you forget to enter all three numbers?\n");
		return 1;
	}
	if (isDouble(a) != 0)
	{
		printf("-> Check number [a]  and write it correctly!\n");
		incorrect_number = true;

	}
	if (isDouble(b) != 0)
	{
		printf("-> Check number [b]  and write it correctly!\n");
		incorrect_number = true;

	}
	if (isDouble(c) != 0)
	{
		printf("-> Check number [c] and write it correctly!\n");
		incorrect_number = true;

	}
	if (incorrect_number)
	{
		return 1;
	}
	double A = atof(a);
	double B = atof(b);
	double C = atof(c);

	long double res = calculate(A, B, C); 
	FILE* resptr = NULL;
	resptr = fopen("output.txt", "w");
	if (!resptr)
	{
		perror("Failed to open output file!!!\n");
		exit(EXIT_FAILURE);
	}
	fprintf(resptr, "%f\n",res);


	return 0;
}